#!/bin/bash
npm install
mkdir nodejs
mv node_modules nodejs
zip -r nodejs.zip  nodejs
